-- Tiry's Zentrale – Design-System: Farben, Schrift, runde Formen, Bausteine
local _, ns = ...

local UI = {}
ns.UI = UI

local MEDIA = ns.MEDIA
local WHITE = "Interface\\Buttons\\WHITE8X8"
UI.TEX = {
  circle = MEDIA .. "circle", ring = MEDIA .. "ring", glow = MEDIA .. "glow",
  blob1 = MEDIA .. "blob1", blob2 = MEDIA .. "blob2", wave = MEDIA .. "wave",
  sparkle = MEDIA .. "sparkle", logo = MEDIA .. "logo", wordmark = MEDIA .. "wordmark",
  emblem = MEDIA .. "emblem", tribal = MEDIA .. "tribal", corner = MEDIA .. "corner",
}


function UI.Icon(name) return MEDIA .. "i_" .. name end

----------------------------------------------------------------------------
-- Farben (Kontrast der Texte auf den Karten >= 4.5:1)
----------------------------------------------------------------------------
local C = {
  -- Anthrazit + Neon-Grün: dunkle Anthrazit-Flächen, Verläufe Neon-Lime -> Neon-Grün -> Smaragd
  bg     = { 0.078, 0.090, 0.090, 0.97 },
  side   = { 0.100, 0.114, 0.114, 0.94 },
  card   = { 0.140, 0.157, 0.157, 0.96 },
  cardHi = { 0.186, 0.207, 0.204, 0.98 },
  inset  = { 0.106, 0.120, 0.120, 0.95 },
  text   = { 0.950, 0.970, 0.960 },
  muted  = { 0.760, 0.810, 0.790 },
  dim    = { 0.570, 0.630, 0.600 },
  gold   = { 0.550, 1.000, 0.300 }, -- Akzent Neon-Lime – Name bleibt für den Code
  amber  = { 0.150, 1.000, 0.450 }, -- Neon-Grün
  rose   = { 0.000, 0.780, 0.550 }, -- leuchtendes Smaragd
  teal   = { 0.100, 0.950, 0.800 },
  violet = { 0.220, 0.400, 0.360 }, -- Schiefergrün
  green  = { 0.380, 0.920, 0.560 },
  red    = { 1.000, 0.440, 0.520 },
  dark   = { 0.030, 0.070, 0.050 },
  hi     = { 1.000, 0.600, 0.160 }, -- Hervorhebung (Orange): wichtige Texte, Werte, Zahlen
}
UI.C = C
UI.GRAD = { C.gold, C.amber, C.rose }        -- Haupt-Verlauf
UI.GRAD_COOL = { C.teal, C.violet, C.rose }  -- Zweit-Verlauf
UI.GRAD_FRESH = { C.green, C.teal, C.violet }

-- Horde-Stil im Hintergrund: Stammesmuster (gekachelt) + Zacken-Ecken. Sehr dezent, frisst keine Klicks.
-- opts: w, h (Größe für die Kachelung), pattern (Alpha), corners (Alpha), cornerSize, inset
function UI.Ornaments(frame, opts)
  opts = opts or {}
  local holder = CreateFrame("Frame", nil, frame)
  holder:SetPoint("TOPLEFT", opts.inset or 8, -(opts.inset or 8))
  holder:SetPoint("BOTTOMRIGHT", -(opts.inset or 8), opts.inset or 8)
  holder:SetFrameLevel(frame:GetFrameLevel())
  holder:SetClipsChildren(true)
  local accent = C.amber
  if (opts.pattern or 0) > 0 then
    local t = holder:CreateTexture(nil, "BACKGROUND", nil, -6)
    t:SetTexture(UI.TEX.tribal, "REPEAT", "REPEAT")
    t:SetPoint("TOPLEFT")
    t:SetSize(opts.w, opts.h)
    t:SetTexCoord(0, opts.w / 160, 0, opts.h / 160)
    t:SetVertexColor(accent[1], accent[2], accent[3], opts.pattern)
    holder.pattern = t
  end
  local cs = opts.cornerSize or 64
  local coords = {
    { "TOPLEFT", 0, 1, 0, 1 }, { "TOPRIGHT", 1, 0, 0, 1 },
    { "BOTTOMLEFT", 0, 1, 1, 0 }, { "BOTTOMRIGHT", 1, 0, 1, 0 },
  }
  holder.corners = {}
  for _, cdef in ipairs(coords) do
    local t = holder:CreateTexture(nil, "BACKGROUND", nil, -5)
    t:SetTexture(UI.TEX.corner)
    t:SetSize(cs, cs)
    t:SetPoint(cdef[1])
    t:SetTexCoord(cdef[2], cdef[3], cdef[4], cdef[5])
    t:SetVertexColor(C.gold[1], C.gold[2], C.gold[3], opts.corners or 0.3)
    holder.corners[#holder.corners + 1] = t
  end
  return holder
end

function UI.Hex(c)
  return string.format("|cff%02x%02x%02x", math.floor(c[1] * 255), math.floor(c[2] * 255), math.floor(c[3] * 255))
end

UI.QUALITY = {
  [0] = { 0.62, 0.62, 0.62 }, [1] = { 1, 1, 1 }, [2] = { 0.12, 1, 0 },
  [3] = { 0.0, 0.44, 0.87 }, [4] = { 0.64, 0.21, 0.93 }, [5] = { 1, 0.5, 0 },
}

----------------------------------------------------------------------------
-- Schrift (eigene Poppins-Schrift mit sicherem Rückfall auf die Spielschrift)
----------------------------------------------------------------------------
local FONT_FILES = {
  regular = MEDIA .. "Fonts\\Poppins-Regular.ttf",
  semibold = MEDIA .. "Fonts\\Poppins-SemiBold.ttf",
  bold = MEDIA .. "Fonts\\Poppins-ExtraBold.ttf",
}
local fallbackFont
local function gameFont()
  if fallbackFont then return fallbackFont end
  local f = GameFontNormal and GameFontNormal.GetFont and GameFontNormal:GetFont()
  fallbackFont = f or STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF"
  return fallbackFont
end

function UI.SetFont(fs, size, weight, flags)
  local file = FONT_FILES[weight or "regular"] or FONT_FILES.regular
  local ok, res = pcall(fs.SetFont, fs, file, size, flags or "")
  if not ok or res == false then
    pcall(fs.SetFont, fs, gameFont(), size, flags or "")
  end
end

UI.MIN_FONT = 12 -- gut lesbar: keine Schrift kleiner als 12
function UI.Text(parent, size, weight, color, layer)
  local fs = parent:CreateFontString(nil, layer or "OVERLAY")
  UI.SetFont(fs, math.max(size or 13, UI.MIN_FONT), weight)
  local c = color or C.text
  fs:SetTextColor(c[1], c[2], c[3], c[4] or 1)
  fs:SetJustifyH("LEFT")
  fs:SetJustifyV("MIDDLE")
  fs:SetShadowColor(0, 0, 0, 0.35)
  fs:SetShadowOffset(0, -1)
  return fs
end

-- Setzt Text einzeilig und kürzt ihn wortweise mit "...", bis er in maxW passt (nichts ragt mehr heraus)
function UI.FitText(fs, text, maxW)
  fs:SetText(text)
  if not maxW or fs:GetUnboundedStringWidth() <= maxW then return end
  local words = {}
  for w in text:gmatch("%S+") do words[#words + 1] = w end
  for n = #words - 1, 1, -1 do
    local t = table.concat(words, " ", 1, n):gsub("[,·%-–]+$", "") .. " ..."
    fs:SetText(t)
    if fs:GetUnboundedStringWidth() <= maxW then return end
  end
end

-- Mehrzeiliger Absatz mit fester Breite
function UI.Para(parent, size, color, width, weight)
  local fs = UI.Text(parent, size or 13, weight or "regular", color or C.muted)
  fs:SetJustifyV("TOP")
  fs:SetWordWrap(true)
  fs:SetSpacing(3)
  if width then fs:SetWidth(width) end
  return fs
end

----------------------------------------------------------------------------
-- Runde Formen: Ecken aus Kreis-Viertel + Flächen; Verläufe mit 3 Farben
----------------------------------------------------------------------------
local Round = {}
Round.__index = Round

local function tex(frame, layer, sub, file)
  local t = frame:CreateTexture(nil, layer or "BACKGROUND", nil, sub or 0)
  t:SetTexture(file or WHITE)
  return t
end

function UI.Round(frame, radius, layer, sub)
  local r = setmetatable({ frame = frame, radius = radius or 12, parts = {} }, Round)
  local p = r.parts
  p.tl = tex(frame, layer, sub, UI.TEX.circle); p.tl:SetTexCoord(0, 0.5, 0, 0.5)
  p.tr = tex(frame, layer, sub, UI.TEX.circle); p.tr:SetTexCoord(0.5, 1, 0, 0.5)
  p.bl = tex(frame, layer, sub, UI.TEX.circle); p.bl:SetTexCoord(0, 0.5, 0.5, 1)
  p.br = tex(frame, layer, sub, UI.TEX.circle); p.br:SetTexCoord(0.5, 1, 0.5, 1)
  p.l = tex(frame, layer, sub)
  p.rr = tex(frame, layer, sub)
  p.c1 = tex(frame, layer, sub)
  p.c2 = tex(frame, layer, sub)
  r:Layout()
  frame:HookScript("OnSizeChanged", function() r:Layout() end)
  return r
end

function Round:Layout()
  local f, p = self.frame, self.parts
  local w, h = f:GetWidth() or 0, f:GetHeight() or 0
  local rad = self.radius
  if w > 0 and h > 0 then rad = math.min(rad, w / 2, h / 2) end
  rad = math.max(math.floor(rad + 0.5), 1)
  self.r = rad
  for _, k in ipairs({ "tl", "tr", "bl", "br", "l", "rr", "c1", "c2" }) do p[k]:ClearAllPoints() end
  p.tl:SetSize(rad, rad); p.tl:SetPoint("TOPLEFT", f, "TOPLEFT", 0, 0)
  p.tr:SetSize(rad, rad); p.tr:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, 0)
  p.bl:SetSize(rad, rad); p.bl:SetPoint("BOTTOMLEFT", f, "BOTTOMLEFT", 0, 0)
  p.br:SetSize(rad, rad); p.br:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", 0, 0)
  p.l:SetPoint("TOPLEFT", f, "TOPLEFT", 0, -rad); p.l:SetPoint("BOTTOMRIGHT", f, "BOTTOMLEFT", rad, rad)
  p.rr:SetPoint("TOPRIGHT", f, "TOPRIGHT", 0, -rad); p.rr:SetPoint("BOTTOMLEFT", f, "BOTTOMRIGHT", -rad, rad)
  p.c1:SetPoint("TOPLEFT", f, "TOPLEFT", rad, 0); p.c1:SetPoint("BOTTOMRIGHT", f, "BOTTOM", 0, 0)
  p.c2:SetPoint("TOPLEFT", f, "TOP", 0, 0); p.c2:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -rad, 0)
end

local function setColor(t, c, a)
  t:SetVertexColor(c[1], c[2], c[3], a or c[4] or 1)
end

local function setGrad(t, c1, c2, a)
  local ok = pcall(t.SetGradient, t, "HORIZONTAL",
    CreateColor(c1[1], c1[2], c1[3], a or c1[4] or 1), CreateColor(c2[1], c2[2], c2[3], a or c2[4] or 1))
  if not ok then setColor(t, c1, a) end
end

function Round:SetColor(c, a)
  for _, t in pairs(self.parts) do setColor(t, c, a) end
  self.mode = "solid"
end

-- Waagerechter Verlauf über drei Farben (links -> Mitte -> rechts)
function Round:SetGradient(stops, a)
  local c1, c2, c3 = stops[1], stops[2], stops[3] or stops[2]
  local p = self.parts
  setColor(p.tl, c1, a); setColor(p.bl, c1, a); setColor(p.l, c1, a)
  setColor(p.tr, c3, a); setColor(p.br, c3, a); setColor(p.rr, c3, a)
  setGrad(p.c1, c1, c2, a)
  setGrad(p.c2, c2, c3, a)
  self.mode = "grad"
end

function Round:SetAlpha(a)
  for _, t in pairs(self.parts) do t:SetAlpha(a) end
end

function Round:SetShown(shown)
  for _, t in pairs(self.parts) do t:SetShown(shown) end
end

function Round:SetBlendMode(mode)
  for _, t in pairs(self.parts) do t:SetBlendMode(mode) end
end

----------------------------------------------------------------------------
-- Weiches Leuchten
----------------------------------------------------------------------------
function UI.Glow(frame, color, size, alpha, layer)
  local g = frame:CreateTexture(nil, layer or "BACKGROUND", nil, -6)
  g:SetTexture(UI.TEX.glow)
  g:SetBlendMode("ADD")
  g:SetSize(size, size)
  g:SetVertexColor(color[1], color[2], color[3], alpha or 0.5)
  return g
end

-- Sanfte Endlos-Animation (Atmen/Treiben); respektiert die Einstellung "Animationen"
function UI.Drift(region, dx, dy, duration, alphaFrom, alphaTo)
  local ag = region:CreateAnimationGroup()
  ag:SetLooping("BOUNCE")
  local move = ag:CreateAnimation("Translation")
  move:SetOffset(dx or 0, dy or 0)
  move:SetDuration(duration or 6)
  move:SetSmoothing("IN_OUT")
  if alphaFrom and alphaTo then
    local fade = ag:CreateAnimation("Alpha")
    fade:SetFromAlpha(alphaFrom)
    fade:SetToAlpha(alphaTo)
    fade:SetDuration(duration or 6)
    fade:SetSmoothing("IN_OUT")
  end
  UI.animations = UI.animations or {}
  table.insert(UI.animations, ag)
  return ag
end

function UI.UpdateAnimations()
  local on = not ns.settings or ns.settings.animations ~= false
  for _, ag in ipairs(UI.animations or {}) do
    if on then
      if not ag:IsPlaying() then ag:Play() end
    else
      ag:Stop()
    end
  end
end

----------------------------------------------------------------------------
-- Tooltip-Helfer
----------------------------------------------------------------------------
function UI.SetTooltip(frame, title, body)
  frame:HookScript("OnEnter", function(self)
    local t, b = title, body
    if type(t) == "function" then t, b = t(self) end
    if not t then return end
    GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
    GameTooltip:SetText(t, 1, 0.6, 0.16)
    if b then GameTooltip:AddLine(b, 0.86, 0.92, 0.89, true) end
    GameTooltip:Show()
  end)
  frame:HookScript("OnLeave", function() GameTooltip:Hide() end)
end

----------------------------------------------------------------------------
-- Knöpfe
----------------------------------------------------------------------------
-- Klicks & Co. abgesichert: Ein Fehler in einem Knopf landet in der eigenen Fehleranzeige (/tz fehler)
-- statt still zu verschwinden – und bricht nie das ganze Fenster.
local GUARDED = { OnClick = true, OnEnter = true, OnLeave = true, OnMouseDown = true, OnMouseUp = true, OnDragStart = true, OnDragStop = true }
function UI.Guard(frame)
  local set = frame.SetScript
  frame.SetScript = function(self, script, fn, ...)
    if type(fn) == "function" and GUARDED[script] then
      local f = fn
      fn = function(...) return ns.Safe(f, ...) end
    end
    return set(self, script, fn, ...)
  end
  return frame
end

function UI.SafeButton(parent, name)
  return UI.Guard(CreateFrame("Button", name, parent))
end

local function playClick()
  if PlaySound and SOUNDKIT and SOUNDKIT.U_CHAT_SCROLL_BUTTON then
    pcall(PlaySound, SOUNDKIT.U_CHAT_SCROLL_BUTTON)
  end
end
UI.PlayClick = playClick

-- style: "primary" (Verlauf), "soft" (Karte), "ghost" (nur Umriss-Wirkung)
function UI.Button(parent, label, style, width, height, icon)
  local b = UI.SafeButton(parent)
  b:SetSize(width or 140, height or 32)
  b.style = style or "primary"
  b.bg = UI.Round(b, (height or 32) / 2, "BACKGROUND", 1)
  b.glow = UI.Glow(b, C.amber, (width or 140) * 1.3, 0, "BACKGROUND")
  b.glow:SetPoint("CENTER")
  b.glow:SetHeight((height or 32) * 2.4)
  b.text = UI.Text(b, 13, "semibold", b.style == "primary" and C.dark or C.text)
  b.text:SetPoint("CENTER", icon and 9 or 0, 0)
  b.text:SetText(label or "")
  if icon then
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetTexture(UI.Icon(icon))
    b.icon:SetSize(15, 15)
    b.icon:SetPoint("RIGHT", b.text, "LEFT", -6, 0)
  end
  function b:Paint()
    local hover = self:IsMouseOver() and self:IsEnabled()
    if self.style == "primary" then
      self.bg:SetGradient(UI.GRAD, self:IsEnabled() and 1 or 0.35)
      self.text:SetTextColor(C.dark[1], C.dark[2], C.dark[3], self:IsEnabled() and 1 or 0.6)
      if self.icon then self.icon:SetVertexColor(C.dark[1], C.dark[2], C.dark[3], 1) end
      self.glow:SetAlpha(hover and 0.55 or 0)
    elseif self.style == "cool" then
      self.bg:SetGradient(UI.GRAD_COOL, self:IsEnabled() and (hover and 1 or 0.88) or 0.3)
      self.text:SetTextColor(1, 1, 1, self:IsEnabled() and 1 or 0.6)
      if self.icon then self.icon:SetVertexColor(1, 1, 1, 1) end
      self.glow:SetVertexColor(C.violet[1], C.violet[2], C.violet[3])
      self.glow:SetAlpha(hover and 0.5 or 0)
    elseif self.style == "danger" then
      self.bg:SetColor(C.red, self:IsEnabled() and (hover and 0.55 or 0.32) or 0.12)
      self.text:SetTextColor(1, 1, 1, self:IsEnabled() and 1 or 0.45)
      if self.icon then self.icon:SetVertexColor(1, 1, 1, self:IsEnabled() and 1 or 0.45) end
      self.glow:SetAlpha(0)
    else
      local base = hover and C.cardHi or C.card
      self.bg:SetColor(base, self.style == "ghost" and (hover and 0.9 or 0.55) or 1)
      self.text:SetTextColor(C.text[1], C.text[2], C.text[3], self:IsEnabled() and 1 or 0.45)
      if self.icon then self.icon:SetVertexColor(C.gold[1], C.gold[2], C.gold[3], self:IsEnabled() and 1 or 0.45) end
      self.glow:SetAlpha(0)
    end
  end
  function b:SetLabel(s) self.text:SetText(s) end
  b:SetScript("OnEnter", function(self) self:Paint() end)
  b:SetScript("OnLeave", function(self) self:Paint() end)
  b:SetScript("OnMouseDown", function(self) if self:IsEnabled() then self.text:SetPoint("CENTER", self.icon and 9 or 0, -1) end end)
  b:SetScript("OnMouseUp", function(self) self.text:SetPoint("CENTER", self.icon and 9 or 0, 0) end)
  b:HookScript("OnClick", playClick)
  b:SetScript("OnEnable", function(self) self:Paint() end)
  b:SetScript("OnDisable", function(self) self:Paint() end)
  b:Paint()
  return b
end

-- Runder Symbol-Knopf (z. B. Schließen)
function UI.IconButton(parent, icon, size, tip)
  local b = UI.SafeButton(parent)
  b:SetSize(size or 28, size or 28)
  b.bg = b:CreateTexture(nil, "BACKGROUND")
  b.bg:SetTexture(UI.TEX.circle)
  b.bg:SetAllPoints()
  b.icon = b:CreateTexture(nil, "ARTWORK")
  b.icon:SetTexture(UI.Icon(icon))
  b.icon:SetPoint("CENTER")
  b.icon:SetSize((size or 28) * 0.5, (size or 28) * 0.5)
  local function paint(self)
    local hover = self:IsMouseOver()
    local c = hover and C.cardHi or C.card
    self.bg:SetVertexColor(c[1], c[2], c[3], 1)
    local ic = hover and C.gold or C.muted
    self.icon:SetVertexColor(ic[1], ic[2], ic[3], 1)
  end
  b:SetScript("OnEnter", paint)
  b:SetScript("OnLeave", paint)
  b:HookScript("OnClick", playClick)
  paint(b)
  if tip then UI.SetTooltip(b, tip) end
  return b
end

----------------------------------------------------------------------------
-- Karte (abgerundete Fläche)
----------------------------------------------------------------------------
function UI.Card(parent, radius, color)
  local f = CreateFrame("Frame", nil, parent)
  f.bg = UI.Round(f, radius or 16, "BACKGROUND", 0)
  f.bg:SetColor(color or C.card)
  return f
end

-- Kleine Pille als Etikett ("Level 10+", "AH", ...)
function UI.Chip(parent, text, color, filled)
  local f = CreateFrame("Frame", nil, parent)
  f.bg = UI.Round(f, 10, "BACKGROUND", 2)
  f.text = UI.Text(f, 11, "semibold", color or C.hi)
  f.text:SetPoint("CENTER", 0, 0)
  function f:Set(t, c, isFilled)
    c = c or C.hi
    self.text:SetText(t)
    if isFilled then
      self.bg:SetColor(c, 1)
      self.text:SetTextColor(C.dark[1], C.dark[2], C.dark[3], 1)
    else
      self.bg:SetColor(c, 0.16)
      self.text:SetTextColor(c[1], c[2], c[3], 1)
    end
    self:SetSize(math.ceil(self.text:GetStringWidth()) + 18, 20)
  end
  f:Set(text or "", color, filled)
  return f
end

----------------------------------------------------------------------------
-- Rundes Item-Symbol mit Qualitäts-Ring
----------------------------------------------------------------------------
function UI.ItemIcon(parent, size)
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(size, size)
  f.icon = f:CreateTexture(nil, "ARTWORK")
  f.icon:SetPoint("TOPLEFT", 2, -2)
  f.icon:SetPoint("BOTTOMRIGHT", -2, 2)
  f.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
  if f.CreateMaskTexture then
    local mask = f:CreateMaskTexture()
    mask:SetTexture(UI.TEX.circle, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    mask:SetAllPoints(f.icon)
    f.icon:AddMaskTexture(mask)
  end
  f.ring = f:CreateTexture(nil, "OVERLAY")
  f.ring:SetTexture(UI.TEX.ring)
  f.ring:SetAllPoints()
  function f:SetItem(id)
    local item = ns.Item(id)
    self.icon:SetTexture(item.icon)
    local q = UI.QUALITY[item.quality or 1] or UI.QUALITY[1]
    self.ring:SetVertexColor(q[1], q[2], q[3], 0.9)
  end
  function f:SetIcon(file, color)
    self.icon:SetTexture(file)
    local c = color or C.gold
    self.ring:SetVertexColor(c[1], c[2], c[3], 0.9)
  end
  return f
end

----------------------------------------------------------------------------
-- Scrollbereich mit schlanker, runder Leiste
----------------------------------------------------------------------------
function UI.Scroll(parent)
  local sf = CreateFrame("ScrollFrame", nil, parent)
  local content = CreateFrame("Frame", nil, sf)
  content:SetSize(10, 10)
  sf:SetScrollChild(content)
  sf:EnableMouseWheel(true)

  local track = CreateFrame("Frame", nil, sf)
  track:SetPoint("TOPRIGHT", sf, "TOPRIGHT", -2, -4)
  track:SetPoint("BOTTOMRIGHT", sf, "BOTTOMRIGHT", -2, 4)
  track:SetWidth(6)
  track.bg = UI.Round(track, 3, "BACKGROUND", 0)
  track.bg:SetColor(C.card, 0.8)

  local thumb = CreateFrame("Frame", nil, track)
  thumb:SetWidth(6)
  thumb.bg = UI.Round(thumb, 3, "ARTWORK", 0)
  thumb.bg:SetColor(C.gold, 0.85)
  thumb:EnableMouse(true)

  local function update()
    local range = sf:GetVerticalScrollRange() or 0
    local h = track:GetHeight() or 1
    if range <= 1 then
      track:Hide()
      return
    end
    track:Show()
    local view = sf:GetHeight() or 1
    local th = math.max(h * view / (view + range), 24)
    thumb:SetHeight(th)
    local pos = (sf:GetVerticalScroll() or 0) / range
    thumb:ClearAllPoints()
    thumb:SetPoint("TOP", track, "TOP", 0, -(h - th) * pos)
  end
  sf.UpdateBar = update

  sf:SetScript("OnMouseWheel", function(self, delta)
    local range = self:GetVerticalScrollRange() or 0
    local cur = self:GetVerticalScroll() or 0
    self:SetVerticalScroll(ns.Clamp(cur - delta * 48, 0, range))
    update()
  end)
  sf:SetScript("OnScrollRangeChanged", function(self)
    local range = self:GetVerticalScrollRange() or 0
    if (self:GetVerticalScroll() or 0) > range then self:SetVerticalScroll(range) end
    update()
  end)
  sf:SetScript("OnSizeChanged", function(self, w)
    content:SetWidth(math.max((w or self:GetWidth() or 10) - 14, 10))
    update()
  end)

  -- Ziehen am Griff
  thumb:SetScript("OnMouseDown", function(self)
    local _, cy = GetCursorPosition()
    self.dragStart = cy / (self:GetEffectiveScale() or 1)
    self.scrollStart = sf:GetVerticalScroll() or 0
    self:SetScript("OnUpdate", function(me)
      local _, y = GetCursorPosition()
      y = y / (me:GetEffectiveScale() or 1)
      local range = sf:GetVerticalScrollRange() or 0
      local free = (track:GetHeight() or 1) - (me:GetHeight() or 1)
      if free > 0 then
        local newScroll = me.scrollStart + (me.dragStart - y) / free * range
        sf:SetVerticalScroll(ns.Clamp(newScroll, 0, range))
        update()
      end
    end)
  end)
  thumb:SetScript("OnMouseUp", function(self) self:SetScript("OnUpdate", nil) end)
  thumb:SetScript("OnHide", function(self) self:SetScript("OnUpdate", nil) end)

  function sf:ScrollToTop()
    self:SetVerticalScroll(0)
    update()
  end
  return sf, content
end

----------------------------------------------------------------------------
-- Schalter (Ein/Aus)
----------------------------------------------------------------------------
function UI.Toggle(parent, label, getter, setter, desc, width)
  local f = UI.SafeButton(parent)
  f:SetSize(width or 520, desc and 54 or 36)
  f.label = UI.Text(f, 13, "semibold", C.text)
  f.label:SetPoint("TOPLEFT", 0, desc and -4 or -10)
  f.label:SetText(label)
  if desc then
    f.desc = UI.Para(f, 11, C.dim, (width or 520) - 70)
    f.desc:SetPoint("TOPLEFT", f.label, "BOTTOMLEFT", 0, -3)
    f.desc:SetText(desc)
  end
  local sw = CreateFrame("Frame", nil, f)
  sw:SetSize(44, 24)
  sw:SetPoint("TOPRIGHT", 0, desc and -6 or -6)
  sw.bg = UI.Round(sw, 12, "BACKGROUND", 0)
  sw.knob = sw:CreateTexture(nil, "ARTWORK")
  sw.knob:SetTexture(UI.TEX.circle)
  sw.knob:SetSize(18, 18)
  function f:Refresh()
    local on = getter()
    if on then
      sw.bg:SetGradient(UI.GRAD, 1)
      sw.knob:ClearAllPoints(); sw.knob:SetPoint("RIGHT", -3, 0)
      sw.knob:SetVertexColor(1, 1, 1, 1)
    else
      sw.bg:SetColor(C.cardHi, 1)
      sw.knob:ClearAllPoints(); sw.knob:SetPoint("LEFT", 3, 0)
      sw.knob:SetVertexColor(C.muted[1], C.muted[2], C.muted[3], 1)
    end
  end
  f:SetScript("OnClick", function(self)
    setter(not getter())
    playClick()
    self:Refresh()
  end)
  f:Refresh()
  return f
end

----------------------------------------------------------------------------
-- Segment-Auswahl (Filter-Pillen nebeneinander, mit Umbruch)
----------------------------------------------------------------------------
function UI.Segments(parent, options, onChange, width)
  local f = CreateFrame("Frame", nil, parent)
  f.buttons = {}
  f.value = options[1] and options[1].value
  local maxW = width or 600
  local x, y, rowH = 0, 0, 30
  for i, opt in ipairs(options) do
    local b = UI.SafeButton(f)
    b.value = opt.value
    b.bg = UI.Round(b, 14, "BACKGROUND", 0)
    b.text = UI.Text(b, 12, "semibold", C.muted)
    b.text:SetPoint("CENTER")
    b.text:SetText(opt.label)
    local w = math.ceil(b.text:GetStringWidth()) + 28
    b:SetSize(w, 28)
    if x + w > maxW and x > 0 then
      x = 0
      y = y + rowH + 6
    end
    b:SetPoint("TOPLEFT", x, -y)
    x = x + w + 8
    b:SetScript("OnClick", function(self)
      f:Select(self.value, true)
      playClick()
    end)
    b:SetScript("OnEnter", function() f:Paint() end)
    b:SetScript("OnLeave", function() f:Paint() end)
    f.buttons[i] = b
  end
  f:SetSize(maxW, y + rowH)
  function f:Paint()
    for _, b in ipairs(self.buttons) do
      if b.value == self.value then
        b.bg:SetGradient(UI.GRAD, 1)
        b.text:SetTextColor(C.dark[1], C.dark[2], C.dark[3], 1)
      else
        b.bg:SetColor(b:IsMouseOver() and C.cardHi or C.card, 1)
        b.text:SetTextColor(C.muted[1], C.muted[2], C.muted[3], 1)
      end
    end
  end
  function f:Select(value, fire)
    self.value = value
    self:Paint()
    if fire and onChange then onChange(value) end
  end
  f:Paint()
  return f
end

----------------------------------------------------------------------------
-- Senkrechter Stapel-Layouter für Seiten
----------------------------------------------------------------------------
local Stack = {}
Stack.__index = Stack

function UI.Stack(content, padX)
  return setmetatable({ content = content, y = 0, pad = padX or 0 }, Stack)
end

function Stack:Width()
  return math.max((self.content:GetWidth() or 600) - self.pad * 2, 100)
end

function Stack:Add(region, height, gap, x)
  region:ClearAllPoints()
  region:SetPoint("TOPLEFT", self.content, "TOPLEFT", self.pad + (x or 0), -self.y)
  if height then
    self.y = self.y + height + (gap or 12)
  end
  return region
end

function Stack:Space(h)
  self.y = self.y + h
end

-- Fügt einen Textabsatz ein und rückt um seine echte Höhe vor
function Stack:Para(text, size, color, gap, weight)
  local fs = UI.Para(self.content, size or 13, color, self:Width(), weight)
  fs:SetText(text)
  self:Add(fs, nil)
  self.y = self.y + math.ceil(fs:GetStringHeight()) + (gap or 10)
  return fs
end

function Stack:Title(text, size, color, gap)
  local fs = UI.Text(self.content, size or 17, "bold", color or C.text)
  fs:SetText(text)
  self:Add(fs, nil)
  self.y = self.y + (size or 17) + 6 + (gap or 8)
  return fs
end

function Stack:Finish(extra)
  self.content:SetHeight(self.y + (extra or 20))
end

----------------------------------------------------------------------------
-- Suchfeld (runde Pille mit Lupe)
----------------------------------------------------------------------------
function UI.SearchBox(parent, width, placeholder, onChange)
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(width, 38)
  f.bg = UI.Round(f, 19, "BACKGROUND", 0)
  f.bg:SetColor(C.inset, 1)
  f.icon = f:CreateTexture(nil, "ARTWORK")
  f.icon:SetTexture(UI.Icon("scan"))
  f.icon:SetSize(16, 16)
  f.icon:SetPoint("LEFT", 16, 0)
  f.icon:SetVertexColor(C.gold[1], C.gold[2], C.gold[3], 1)
  local eb = CreateFrame("EditBox", nil, f)
  eb:SetPoint("TOPLEFT", 42, -4)
  eb:SetPoint("BOTTOMRIGHT", -16, 4)
  eb:SetAutoFocus(false)
  eb:SetMaxLetters(60)
  local ok, res = pcall(eb.SetFont, eb, ns.MEDIA .. "Fonts\\Poppins-Regular.ttf", 14, "")
  if not ok or res == false then pcall(eb.SetFont, eb, STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 14, "") end
  eb:SetTextColor(C.text[1], C.text[2], C.text[3], 1)
  f.hint = UI.Text(f, 13, "regular", C.dim)
  f.hint:SetPoint("LEFT", 42, 0)
  f.hint:SetText(placeholder or "Suchen ...")
  eb:SetScript("OnTextChanged", function(self)
    local t = self:GetText() or ""
    f.hint:SetShown(t == "")
    if onChange then onChange(t) end
  end)
  eb:SetScript("OnEscapePressed", function(self) self:ClearFocus() end)
  eb:SetScript("OnEnterPressed", function(self) self:ClearFocus() end)
  eb:SetScript("OnEditFocusGained", function() f.bg:SetColor(C.cardHi, 1) end)
  eb:SetScript("OnEditFocusLost", function() f.bg:SetColor(C.inset, 1) end)
  f:EnableMouse(true)
  f:SetScript("OnMouseDown", function() eb:SetFocus() end)
  f.edit = eb
  return f
end

----------------------------------------------------------------------------
-- Kompakter Regler:  Beschriftung   (-)  Wert  (+)
----------------------------------------------------------------------------
function UI.Stepper(parent, label, width, getter, setter, step, min, max, format, parse, hint)
  local f = CreateFrame("Frame", nil, parent)
  f:SetSize(width, 34)
  f.bg = UI.Round(f, 17, "BACKGROUND", 0)
  f.bg:SetColor(C.card, 1)
  f.label = UI.Text(f, 12, "semibold", C.muted)
  f.label:SetPoint("LEFT", 14, 0)
  f.label:SetText(label)
  local plus = UI.IconButton(f, "plus", 26)
  plus:SetPoint("RIGHT", -4, 0)
  f.value = UI.Text(f, 12, "bold", C.hi)
  f.value:SetWidth(76)
  f.value:SetJustifyH("CENTER")
  f.value:SetPoint("RIGHT", plus, "LEFT", -2, 0)
  local minus = UI.IconButton(f, "minus", 26)
  minus:SetPoint("RIGHT", f.value, "LEFT", -2, 0)
  function f:Refresh() self.value:SetText(format(getter())) end
  -- Freie Eingabe: Klick auf den Wert -> Eingabefeld (Enter übernimmt, Esc bricht ab)
  if parse then
    local hit = UI.SafeButton(f)
    hit:SetAllPoints(f.value)
    local eb = CreateFrame("EditBox", nil, f)
    eb:SetSize(84, 24)
    eb:SetPoint("CENTER", f.value, "CENTER")
    eb:SetAutoFocus(false)
    eb:SetMaxLetters(12)
    eb:SetJustifyH("CENTER")
    local ok, res = pcall(eb.SetFont, eb, ns.MEDIA .. "Fonts\\Poppins-SemiBold.ttf", 12, "")
    if not ok or res == false then pcall(eb.SetFont, eb, STANDARD_TEXT_FONT or "Fonts\\FRIZQT__.TTF", 12, "") end
    eb:SetTextColor(1, 1, 1, 1)
    eb.bg = UI.Round(eb, 10, "BACKGROUND", 3)
    eb.bg:SetColor(C.inset, 1)
    eb:Hide()
    local function finish(apply)
      if apply then
        local v = parse(eb:GetText())
        if v then
          setter(math.max(min, math.min(max, v)))
          if f.onChange then f.onChange() end
        else
          ns.Print("Bitte eine Zahl eingeben, z. B. 45 (Silber), 1g 20s oder 1,5g.")
        end
      end
      eb:ClearFocus()
      eb:Hide()
      f.value:Show()
      f:Refresh()
    end
    eb:SetScript("OnEnterPressed", function() finish(true) end)
    eb:SetScript("OnEscapePressed", function() finish(false) end)
    eb:SetScript("OnEditFocusLost", function() if eb:IsShown() then finish(true) end end)
    hit:SetScript("OnClick", function()
      f.value:Hide()
      eb:SetText("")
      eb:Show()
      eb:SetFocus()
    end)
    if hint then UI.SetTooltip(hit, "Selbst eintragen", hint) end
    f.edit, f.hit = eb, hit
  end
  local function change(dir)
    local v = getter() + dir * (type(step) == "function" and step(getter(), dir) or step)
    setter(math.max(min, math.min(max, v)))
    f:Refresh()
    if f.onChange then f.onChange() end
  end
  plus:SetScript("OnClick", function() change(1) end)
  minus:SetScript("OnClick", function() change(-1) end)
  -- Rückgängig: × rechts neben dem Regler, sobald der Wert vom Standard abweicht
  function f:SetDefault(def, onReset)
    self.default, self.onReset = def, onReset
    if not self.reset then
      self.reset = UI.IconButton(self, "close", 24, "Zurück auf Standard")
      self.reset:SetPoint("LEFT", self, "RIGHT", 6, 0)
      self.reset:SetScript("OnClick", function()
        local d = type(self.default) == "function" and self.default() or self.default
        if self.onReset then self.onReset() else setter(d) end
        self:Refresh()
        if self.onChange then self.onChange() end
      end)
    end
    self:Refresh()
  end
  function f:Refresh()
    self.value:SetText(format(getter()))
    if self.reset then
      local d = type(self.default) == "function" and self.default() or self.default
      self.reset:SetShown(getter() ~= d)
    end
  end
  f:Refresh()
  return f
end

-- Kleiner Umschalter als Pille (an = Verlauf)
function UI.Pill(parent, label, getter, setter, onChange)
  local b = UI.Button(parent, label, "soft", nil, 30)
  b:SetWidth(math.ceil(b.text:GetStringWidth()) + 34)
  local function paint()
    b.style = getter() and "primary" or "soft"
    b:Paint()
  end
  b:SetScript("OnClick", function()
    setter(not getter())
    paint()
    if onChange then onChange() end
  end)
  b.Refresh = paint
  paint()
  return b
end
